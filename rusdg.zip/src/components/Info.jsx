import React from "react";

function Info(){
  return(
    <div className="note">
    <h1>JAVASCRIPT AND REACT.JS</h1>
    <p>A Basic Web Dev React Js Bootcamp</p>
    </div>
  );
}

export default Info;